% simple_fusion.m
load('matlab/resRand.mat');
load('matlab/resRandRGB.mat');
load('matlab/resSAR.mat');

Savg = (resRand.scoresAvg + resRandRGB.scoresAvg + resSAR.scoresAvg) / 3;
[~, pred] = max(Savg, [], 2);
acc = mean(pred(:) == double(resRand.yTrue));
fprintf('Fusion Accuracy: %.4f\n', acc);